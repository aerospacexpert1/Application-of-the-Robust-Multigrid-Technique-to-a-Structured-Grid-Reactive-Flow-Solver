#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
./verify_campaign.sh
build_job=$(sbatch --parsable build_mg2v.slurm)
run_job=$(sbatch --parsable --dependency=afterok:${build_job} mg2v_96_array.slurm)
echo "Build job: $build_job"
echo "96-case array job: $run_job"
echo "Monitor: squeue -j $run_job"
echo "Status:  ./check_campaign_status.sh"

#!/usr/bin/env python3
"""Numerical checks outside the measured campaign. Run inside a compute allocation."""
import argparse
import math
from pathlib import Path
import subprocess
import os
import tempfile
from campaign import ROOT, SOLVERS, cases, execute

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--binary',default=str(ROOT/'build/mms_solver'))
    args=p.parse_args()
    binary=Path(args.binary).resolve()
    rows=cases()
    results=[]
    with tempfile.TemporaryDirectory(prefix='smoke_',dir=ROOT/'build') as tmp:
        for sol in SOLVERS:
            for n in (1,2):
                c=next(r for r in rows if r['stiffness']=='S1' and r['mesh']=='M1' and r['solver']==sol and r['threads']==str(n))
                rc,r=execute(binary,c,Path(tmp)/(sol+'_T'+str(n)))
                assert rc==0 and r['converged']=='1', (c,r)
                assert float(r['relative_residual'])<=1e-7, r
                results.append(r)
        ref=results[0]
        for r in results:
            for k in ('YF_L2','YO_L2','YP_L2'):
                assert math.isclose(float(r[k]),float(ref[k]),rel_tol=2e-5,abs_tol=1e-9),(k,r)
        env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',OMP_DYNAMIC='FALSE')
        out=Path(tmp)/'cap.csv'
        q=subprocess.run([str(binary),'--solver','SG_RBGS','--max-iter','3','--out',str(out)],env=env,capture_output=True)
        import csv
        r=list(csv.DictReader(out.open()))[0]
        assert q.returncode==3 and r['converged']=='0' and int(r['iterations'])==9
        q=subprocess.run([str(binary),'--solver','TYPO'],env=env,capture_output=True)
        assert q.returncode==2
        q=subprocess.run([str(binary),'--expected-threads','2'],env=env,capture_output=True)
        assert q.returncode==2 and b'actual OpenMP' in q.stderr
    print('PASS: five solvers x threads 1/2, matching species errors, strict cap, solver typo and actual-thread rejection')
    for r in results:
        print(r['solver'],r['threads'],r['iterations'],r['relative_residual'])

if __name__=='__main__': main()

# Benchmark C — Orfoz, one measurement per case (2026-10-06)

## Çalıştırma

ZIP'i **yeni bir klasöre** aç. Eski `Benchmark_C_audit_2026-10-04` klasörünün üzerine açma.
Bu paket mevcut Slurm işlerini iptal etmez ve onların sonuçlarını içeri almaz.

```bash
cd Benchmark_C_Orfoz_single_2026-10-06
bash build.sh
bash submit_all.sh
```

`submit_all.sh` tek `sbatch` çağrısıyla 300 case'i verir. Öncesinde ayrıca eski
`verify_baseline.py` veya 3 tekrarlı campaign komutu çalıştırmak gerekmez.
GCC PATH'te yoksa kendi önceki Orfoz ortamındaki GCC modülünü yükle.

Durum ve temel CSV:

```bash
squeue -u "$USER"
python3 collect_summary.py
```

Çıktı: `Benchmark_C_campaign_summary.csv` — önceki CSV ile aynı **26 sütun**.
CSV yalnızca tamamlanmış gerçek ölçümleri içerir; yakınsamamış ölçümler
`converged=0` olarak korunur. Eksik/çalışan case'ler terminalde listelenir.
`RUNNING_OR_INCOMPLETE` tek başına kesilmiş iş demek değildir; `squeue` ile bakılır.
CSV yeniden toplandığında önceki toplama `.csv.previous` olarak korunur.

## Sabit campaign

- Orfoz; eski yerel paket gibi 56 CPU allocation, exclusive node, 3 günlük grup walltime.
- `--array=0-59%3`: 60 grup, aynı anda en fazla 3 grup.
- Bir grupta sabit S/mesh/thread için sırayla SG-RBGS, MG2-V, MG2-W, MG3-V, RMT.
- 3 S-case × 5 mesh × 4 thread × 5 solver = **300 case; her biri 1 kez**.
- Gerçek OpenMP thread sayıları 1/2/4/16; 56 CPU allocation, 56 solver thread demek değildir.
- 1e-7 relative residual hedefi; **her tür için 240000 sweep/cycle sınırı**.
- SG sayacı tam red–black sweep; multilevel sayaç tam cycle; CSV üç türün toplamıdır.
- Warm-up yok, otomatik tekrar yok, case başına ayrı 4 saat timeout yok.
- `OMP_DYNAMIC=FALSE`, `OMP_PLACES=cores`, `OMP_PROC_BIND=close`; gerçek team size denetlenir.
- Stopping ve `converged` aynı 1e-7 toleransını kullanır. Eski gevşek 1e-6 success flag düzeltilmiştir.

%3, Slurm array eşzamanlılık üst sınırıdır; hesap/QOS daha düşük sınırlıyorsa diğer işler bekler.
Orfoz/56 seçimi PDF ve eski yerel betikten alınmıştır. Gerçek hesap iznini yerelde doğrulayamayız;
Slurm bunu reddederse hata mesajına göre Orfoz hesabı/QOS çözülmeli, paket otomatik Barbun'a geçmez.

## PDF ve kaynak kontrolü

`PDF_CODE_CHECK.md` problem/çözücü karşılaştırmasını ve doğrulamanın sınırını açıklar.
Kaynak, 2026-10-04 audit içindeki **yerel V2** sürümüdür. Bu pakette PDE,
manufactured alanlar, transferler ve smoothing değiştirilmedi. Kaynakta yalnızca
CSV yazımı temel şemaya döndürüldü. Numerical kernel hash karşılaştırması raporda kayıtlıdır.
PDF'deki eski sayısal sonuçları üreten kaynak sürümü kesinleşmediğinden bu yeni
ölçümlerin eski CSV'yi aynen üretmesi garanti edilmez. İki kaynak/sunucu sürümü
arasındaki walltime sonuçları birleştirilmemelidir.

Numerical smoke testi isteğe bağlıdır; **compute allocation içinde**:

```bash
python3 smoke_test.py
```

Bu kontrol 300 ölçümün parçası değildir; geçici küçük-grid çıktıları silinir.
TRUBA GCC/Slurm çalışması yerelde yapılmamıştır. Yerel doğrulama kapsamı
`QA_REPORT.json` içinde belirtilir.

`build/SHA256SUMS` her işte kaynak/manifest/binary tutarlılığını kontrol eder.
Recorded case'ler ikinci kez çalıştırılmaz; yarım kalmış deneme otomatik tekrar edilmez.
Grup yeniden başlatılacaksa önce yarım kalan case'in Slurm'da çalışmadığını doğrula,
o case klasörünü yedekle/taşı; sonra ilgili group id'sini yeniden ver.

```bash
# Yalnızca gerekli grubun açık yeniden gönderimi; G=0..59
sbatch --array=G benchmark_C_array.slurm
```

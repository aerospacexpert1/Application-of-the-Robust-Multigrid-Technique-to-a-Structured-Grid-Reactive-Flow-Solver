#!/usr/bin/env python3
"""Single measurement per case; 60 groups of five solvers; original 26-column CSV."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import socket
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
SOLVERS = ('SG_RBGS', 'MG2V', 'MG2W', 'MG3V', 'RMT3H')
MESHES = ((108,36), (216,72), (432,144), (864,288), (1728,576))
THREADS = (1,2,4,16)
TOL = 1e-7
MAX_ITER = 240000
FIELDS = ('benchmark,stiffness,Nx,Ny,threads,solver,converged,iterations,'
          'relative_residual,L1,L2,Linf,solve_wall_time,total_relevant_wall_time,'
          'continuity_metric,p_L2,u_L2,v_L2,YF_L2,YO_L2,YP_L2,h_L2,T_L2,rho_L2,'
          'T_rel_L2,rho_rel_L2').split(',')

def cases():
    with (ROOT/'campaign_manifest.csv').open(newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 300:
        raise ValueError('Manifest must contain exactly 300 cases')
    expected = [(f'S{s}', f'M{m}', str(nx), str(ny), f'T{n}', str(n), sol)
                for s in (1,2,3) for m,(nx,ny) in enumerate(MESHES,1)
                for n in THREADS for sol in SOLVERS]
    for i,(r,e) in enumerate(zip(rows,expected)):
        got = tuple(r[k] for k in ('stiffness','mesh','Nx','Ny','thread_label','threads','solver'))
        if r['task_id'] != str(i) or got != e:
            raise ValueError(f'Manifest case {i} does not match the frozen campaign')
    return rows

def case_dir(case, results=None):
    return (Path(results) if results is not None else ROOT/'results') / case['stiffness'] / case['mesh'] / case['thread_label'] / case['solver']

def read_row(path, case):
    with Path(path).open(newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != FIELDS:
            raise ValueError('Unexpected summary columns')
        rows = list(reader)
    if len(rows) != 1:
        raise ValueError('Expected one measured row per case')
    r = rows[0]
    for k in ('stiffness','Nx','Ny','threads','solver'):
        if r[k] != case[k]:
            raise ValueError(f'Wrong {k} for task {case["task_id"]}')
    if r['benchmark'] != 'C' or r['converged'] not in ('0','1'):
        raise ValueError('Invalid benchmark/status')
    count = int(r['iterations'])
    if not 0 <= count <= 3*MAX_ITER:
        raise ValueError('Invalid summed sweep/cycle count')
    values = [float(r[k]) for k in FIELDS[8:]]
    if r['converged'] == '1':
        if not all(math.isfinite(v) and v >= 0 for v in values):
            raise ValueError('Nonfinite/negative accepted row')
        if float(r['relative_residual']) > TOL:
            raise ValueError('Accepted row does not meet 1e-7')
        if float(r['solve_wall_time']) <= 0:
            raise ValueError('Invalid accepted timing')
    return r

def execute(binary, case, directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    n = case['threads']
    env.update(OMP_NUM_THREADS=n, OMP_THREAD_LIMIT=n, OMP_DYNAMIC='FALSE',
               OMP_PLACES='cores', OMP_PROC_BIND='close')
    argv = [str(binary),'--Nx',case['Nx'],'--Ny',case['Ny'],'--stiffness',case['stiffness'],
            '--solver',case['solver'],'--expected-threads',n,'--tol',str(TOL),
            '--max-iter',str(MAX_ITER),'--out',str(directory/'case_summary.csv')]
    # No warm-up run, no repeats, no per-case four-hour kill.
    with (directory/'run.log').open('w', encoding='utf-8') as log:
        rc = subprocess.run(argv, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    if rc not in (0,3):
        raise RuntimeError(f'Solver exit {rc}; see {directory / "run.log"}')
    row = read_row(directory/'case_summary.csv', case)
    if (rc == 0) != (row['converged'] == '1'):
        raise ValueError('Exit code and strict convergence flag disagree')
    return rc, row

def run_case(case, results=None, binary=None):
    binary = Path(binary) if binary is not None else ROOT/'build/mms_solver'
    directory = case_dir(case, results)
    directory.mkdir(parents=True, exist_ok=True)
    # Lock even a restarted group so one case cannot execute twice concurrently.
    lock = directory/'running.lock'
    fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.write(fd, f'{socket.gethostname()} pid={os.getpid()}\n'.encode())
    os.close(fd)
    try:
        if (directory/'finished').exists():
            row = read_row(directory/'case_summary.csv', case)
            print(f'SKIP recorded task={case["task_id"]} converged={row["converged"]}', flush=True)
            return row
        if (directory/'started').exists():
            raise RuntimeError(f'An incomplete attempt exists at {directory}; inspect it before restarting')
        (directory/'started').write_text(datetime.now(timezone.utc).isoformat()+'\n', encoding='utf-8')
        try:
            rc,row = execute(binary,case,directory)
        except Exception:
            (directory/'failed').touch()
            raise
        (directory/'solver_exit_code').write_text(str(rc)+'\n', encoding='utf-8')
        (directory/'finished').touch()
        print(f'task={case["task_id"]} {case["stiffness"]}/{case["mesh"]}/{case["thread_label"]}/{case["solver"]} converged={row["converged"]} residual={row["relative_residual"]}', flush=True)
        return row
    finally:
        lock.unlink()

def record_build(results):
    results.mkdir(parents=True, exist_ok=True)
    hashes = ROOT/'build/SHA256SUMS'
    if not hashes.is_file():
        raise RuntimeError('Run bash build.sh first')
    stamp = hashes.read_bytes()
    path = results/'BUILD_SHA256SUMS'
    # Publish only a complete stamp: three array tasks may arrive together.
    import tempfile
    fd, name = tempfile.mkstemp(prefix='.build_stamp_', dir=results)
    candidate = Path(name)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(stamp)
        try:
            os.link(candidate,path)
        except FileExistsError:
            if path.read_bytes() != stamp:
                raise RuntimeError('Source/build differs from existing results; use a fresh directory')
    finally:
        candidate.unlink()

def run_group(group):
    rows = cases()
    if not 0 <= group < 60:
        raise ValueError('Group must be in 0..59')
    record_build(ROOT/'results')
    # Minimal platform evidence in the Slurm text log, not extra scientific CSVs.
    print(f'GROUP={group} HOST={socket.gethostname()} JOB={os.environ.get("SLURM_JOB_ID","local")} PARTITION={os.environ.get("SLURM_JOB_PARTITION","local")}', flush=True)
    failed = False
    for case in rows[group*5:group*5+5]:
        try:
            run_case(case)
        except Exception as exc:
            failed = True
            print(f'task={case["task_id"]} FAILED: {exc}', file=sys.stderr, flush=True)
    return 2 if failed else 0

def collect(results=None, output=None):
    results = Path(results) if results is not None else ROOT/'results'
    output = Path(output) if output is not None else ROOT/'Benchmark_C_campaign_summary.csv'
    found = []
    status = dict(CONVERGED=0, NONCONVERGED=0, RUNNING_OR_INCOMPLETE=0, FAILED=0, MISSING=0)
    unfinished = []
    for c in cases():
        d = case_dir(c,results)
        state = 'MISSING'
        if (d/'finished').exists():
            try:
                r = read_row(d/'case_summary.csv',c)
                found.append(r)
                state = 'CONVERGED' if r['converged']=='1' else 'NONCONVERGED'
            except Exception as exc:
                state = 'FAILED'
                print(f'task={c["task_id"]}: invalid result: {exc}', file=sys.stderr)
        elif (d/'failed').exists():
            state = 'FAILED'
        elif (d/'started').exists() or (d/'running.lock').exists():
            state = 'RUNNING_OR_INCOMPLETE'
        status[state] += 1
        if state not in ('CONVERGED','NONCONVERGED'):
            unfinished.append(f'task={c["task_id"]:>3} group={int(c["task_id"])//5:>2} {c["stiffness"]} {c["mesh"]} {c["solver"]:7} T{c["threads"]:>2} {state}')
    # Only actual finished measurements enter the CSV; never fabricate missing rows.
    if output.exists():
        if output.name != 'Benchmark_C_campaign_summary.csv':
            raise ValueError('Use the package summary name; do not overwrite an imported baseline')
        # One rotating snapshot prevents accumulating a large output collection.
        backup = output.with_suffix('.csv.previous')
        import shutil
        print('Previous summary SHA256: '+hashlib.sha256(output.read_bytes()).hexdigest())
        shutil.copyfile(output, backup)
    temporary = output.with_suffix('.csv.tmp')
    with temporary.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f,fieldnames=FIELDS,lineterminator='\n')
        writer.writeheader()
        writer.writerows(found)
    temporary.replace(output)
    print(json.dumps(status,indent=2))
    print(f'{len(found)}/300 measured rows -> {output}')
    if unfinished:
        print('Pending/unrecorded cases:')
        print('\n'.join(unfinished))
    return status

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command',required=True)
    sub.add_parser('check')
    sub.add_parser('collect')
    q = sub.add_parser('run-group'); q.add_argument('group',type=int)
    q = sub.add_parser('run-case'); q.add_argument('task',type=int)
    a = p.parse_args()
    if a.command == 'check':
        cases()
        print('OK: 300 unique cases, 60 groups x 5 solvers, exactly 1 measurement/case')
    elif a.command == 'collect':
        collect()
    elif a.command == 'run-group':
        return run_group(a.group)
    else:
        rows=cases()
        if not 0<=a.task<300: raise ValueError('Task must be in 0..299')
        record_build(ROOT/'results')
        run_case(rows[a.task])
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError,RuntimeError,OSError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        sys.exit(2)

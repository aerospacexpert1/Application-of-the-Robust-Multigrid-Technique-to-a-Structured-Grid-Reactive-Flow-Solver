#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 campaign.py run-case "${1:?task index required}"

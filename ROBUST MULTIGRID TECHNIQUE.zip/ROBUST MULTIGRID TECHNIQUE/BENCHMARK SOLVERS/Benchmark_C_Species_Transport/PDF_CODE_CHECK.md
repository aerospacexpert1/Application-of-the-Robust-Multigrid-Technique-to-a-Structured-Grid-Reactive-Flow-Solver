# PDF–code comparison

Source: `B:/MY_THESIS_FINAL_DRAFT (7).pdf`, SHA256 recorded in PROVENANCE.json.
PDF page numbers below count from the first file page; printed thesis numbers in parentheses.

| PDF statement | Package implementation | Check |
|---|---|---|
| §4.1.1, pp.64–65 (36–37): [0,3]×[0,1], S1/S2/S3, five meshes, threads1/2/4/16, five solvers,300 cases | allocsys; frozen campaign_manifest.csv | matches |
| §4.4.1, p.76 (48), Eq.4.10: div(rho*u*Y)-div(rho*D_k*grad Y)=source | assemble convection face fluxes; mms_diff **is effective rho*D_k**, not molecular D_k | matches operator; do not multiply mms_diff by rho again |
| Eq.4.10 chemistry disabled, three species | f/o/p solved independently; no reaction term | matches |
| §4.1, continuous manufactured source; exact boundary data; common initial guess | unchanged mms_generated.h; exact Dirichlet trace, zero interior initial state | matches; analytical source checked independently |
| §4.1.2, pp.65–66 (37–38): RMS over all sampled points; relative interior L2 residual; total species counts/timing; largest residual | norms, residual, one_species and main | matches |
| §4.1.1:1e-7 stopping; text distinguishes older1e-6 acceptance | strict1e-7 stopping and flag | intentional correction of historical inconsistency |
| §3.3.1, p.47 (19): red then black, same-color parallel five-point stencil | rbgs, complete two-color sweeps, OpenMP for loops | matches |
| §3.3.2, pp.49–52 (21–24): MG2-V ratio2/V, MG2-W ratio2/W, MG3-V ratio3/V | mg_cycle_ref(s,2,2,1), (s,2,2,2), (s,3,2,1) | matches strategy |
| §3.3.3, pp.52–54 (24–26): RMT factor3, nine shifted coarse corrections, recursive hierarchy | rmt_error_recursive, sx/sy=0..2, recursive correction and index-space injection | matches strategy; not a single MG3-V path |
| §3.5, pp.61–62 (33–34): Orfoz/GCC/OpenMP; allocation separate from active threads | Orfoz,56 allocation,1/2/4/16 threads,gcc-O2-fopenmp | matches platform intention; account permissions not tested locally |

## Preserved source choices not fully specified by the PDF

The PDF describes strategy-level algorithms; it does not supply all executable details.
The following are **preserved local V2 choices**, not independently derived from the PDF:
nodal sampling dx=3/(Nx-1),dy=1/(Ny-1); first-order face upwinding;
centered diffusion; effective diffusivity shared by the three manufactured species;
MG 3 pre/3 post RBGS sweeps, two coarse transitions (where size allows),
40 leaf RBGS sweeps, averaging restriction and interpolation prolongation;
RMT no presmoothing,16 post sweeps, averaging restriction, nine shifted index-space
corrections, direct dense leaf solve, size/depth termination.

RMT leaf termination is level>=5 or Nx<12 or Ny<8; it uses the same global smoothing
configuration at every nonleaf and for every case. No new damping, fallback,
mixFactor, chemistry calibration, or solver-specific tuning was added.

The inherited coarse operators and index transfers are not certified as an exact
reproduction of Martynenko's black-box implementation. The thesis itself calls its
realizations RMT-oriented (§2.4, PDF p.40). This package verifies the stated operator
and retains the supplied implementation; it does not establish optimal intergrid design.

## Limit on reproducing the old numerical tables

The preexisting thesis CSV and the available local V2 source did not agree in the
2026-10-04 baseline tests (e.g. S1/M1/T1 MG3-V: old37 total cycles vs local V2 833).
The same discrepancy was observed in the user's TRUBA GCC output. Therefore
"same PDE and five solver strategies" must not be presented as proof that this is
the exact build that generated the thesis's historical tables. All new measurements
must be treated as a separately identified campaign; do not combine old and new timings.

The original S-fields/header are preserved byte-for-byte from both archived local V2
and GitHub V2. The PDF's figures show these qualitative field structures but do not
list every analytical field coefficient, smoothing count or transfer weight.

#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build logs
# Never rebuild over results: preserve the recorded binary/source version.
if [[ -d results ]] && find results -name case_summary.csv -print -quit | grep -q .; then
    echo "Results already exist. Use a fresh extraction to rebuild." >&2
    exit 2
fi
: "${CC:=gcc}"
"$CC" -O2 -std=c11 -fopenmp -Wall -Wextra -pedantic -DBENCH_ID=67 src/mms_solver.c -lm -o build/mms_solver
"$CC" --version > build/compiler.txt
printf '%s\n' "$CC -O2 -std=c11 -fopenmp -Wall -Wextra -pedantic -DBENCH_ID=67 src/mms_solver.c -lm -o build/mms_solver" > build/command.txt
sha256sum src/mms_solver.c src/mms_generated.h campaign_manifest.csv campaign.py benchmark_C_array.slurm build/mms_solver > build/SHA256SUMS
echo "Built Benchmark C. Submit with: bash submit_all.sh"

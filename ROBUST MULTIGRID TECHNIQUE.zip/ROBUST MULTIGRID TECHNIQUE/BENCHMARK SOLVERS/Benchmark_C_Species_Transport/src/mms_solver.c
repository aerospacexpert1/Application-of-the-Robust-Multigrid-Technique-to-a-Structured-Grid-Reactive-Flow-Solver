#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>
#include <errno.h>
#include <limits.h>
#ifdef _WIN32
#include <windows.h>
#endif
#include "mms_generated.h"
#ifndef BENCH_ID
#define BENCH_ID 'A'
#endif
#define IDX(i,j,nx) ((j)*(nx)+(i))
typedef struct {int nx,ny; double dx,dy; char var; int st; double *ap,*ae,*aw,*an,*as,*b,*q,*exact;} Sys;
static double wall(void){
#ifdef _WIN32
    LARGE_INTEGER t, frequency;
    QueryPerformanceCounter(&t); QueryPerformanceFrequency(&frequency);
    return (double)t.QuadPart/(double)frequency.QuadPart;
#else
    struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
    return t.tv_sec+1e-9*t.tv_nsec;
#endif
}
static void die(const char*s){fprintf(stderr,"%s\n",s);exit(2);} 
static void allocsys(Sys*s,int nx,int ny){memset(s,0,sizeof(*s));s->nx=nx;s->ny=ny;s->dx=3.0/(nx-1);s->dy=1.0/(ny-1);size_t n=(size_t)nx*ny; s->ap=calloc(n,sizeof(double));s->ae=calloc(n,sizeof(double));s->aw=calloc(n,sizeof(double));s->an=calloc(n,sizeof(double));s->as=calloc(n,sizeof(double));s->b=calloc(n,sizeof(double));s->q=calloc(n,sizeof(double));s->exact=calloc(n,sizeof(double));if(!s->ap||!s->ae||!s->aw||!s->an||!s->as||!s->b||!s->q||!s->exact)die("alloc");}
static void freesys(Sys*s){free(s->ap);free(s->ae);free(s->aw);free(s->an);free(s->as);free(s->b);free(s->q);free(s->exact);} 
static double exvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_u(x,y,st):mms_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_YF(x,y,st):(var=='o'?mms_YO(x,y,st):mms_YP(x,y,st));
 if(var=='f')return mms_YF(x,y,st); if(var=='o')return mms_YO(x,y,st); if(var=='p')return mms_YP(x,y,st); if(var=='h')return mms_h(x,y,st); return mms_T(x,y,st);
}
static double srcvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_src_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_src_u(x,y,st):mms_src_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_src_YF(x,y,st):(var=='o'?mms_src_YO(x,y,st):mms_src_YP(x,y,st));
 if(var=='f')return mms_src_YF(x,y,st); if(var=='o')return mms_src_YO(x,y,st); if(var=='p')return mms_src_YP(x,y,st); return mms_src_h(x,y,st);
}
static void assemble(Sys*s,char var,int st){s->var=var;s->st=st;int nx=s->nx,ny=s->ny;double dx=s->dx,dy=s->dy;
 #pragma omp parallel for collapse(2)
 for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double xx=i*dx,yy=j*dy;s->exact[k]=exvar(var,xx,yy,st);s->q[k]=s->exact[k]; if(i==0||j==0||i==nx-1||j==ny-1){s->ap[k]=1;s->b[k]=s->exact[k];continue;}
   double rho=mms_rho(xx,yy,st),ua=mms_uadv(xx,yy,st),va=mms_vadv(xx,yy,st),dif=mms_diff(xx,yy,st); double vol=dx*dy;
   if(BENCH_ID=='A'){double De=dy/dx,Dw=dy/dx,Dn=dx/dy,Ds=dx/dy;s->ae[k]=De;s->aw[k]=Dw;s->an[k]=Dn;s->as[k]=Ds;s->ap[k]=De+Dw+Dn+Ds;s->b[k]=srcvar(var,xx,yy,st)*vol;continue;}
   double re=mms_rho(xx+0.5*dx,yy,st),rw=mms_rho(xx-0.5*dx,yy,st),rn=mms_rho(xx,yy+0.5*dy,st),rs=mms_rho(xx,yy-0.5*dy,st);double ue=mms_uadv(xx+0.5*dx,yy,st),uw=mms_uadv(xx-0.5*dx,yy,st),vn=mms_vadv(xx,yy+0.5*dy,st),vs=mms_vadv(xx,yy-0.5*dy,st);double de=mms_diff(xx+0.5*dx,yy,st),dw=mms_diff(xx-0.5*dx,yy,st),dn=mms_diff(xx,yy+0.5*dy,st),ds=mms_diff(xx,yy-0.5*dy,st);double Fe=re*ue*dy,Fw=rw*uw*dy,Fn=rn*vn*dx,Fs=rs*vs*dx;double De=de*dy/dx,Dw=dw*dy/dx,Dn=dn*dx/dy,Ds=ds*dx/dy;s->ae[k]=De+fmax(-Fe,0);s->aw[k]=Dw+fmax(Fw,0);s->an[k]=Dn+fmax(-Fn,0);s->as[k]=Ds+fmax(Fs,0);s->ap[k]=s->ae[k]+s->aw[k]+s->an[k]+s->as[k]+(Fe-Fw+Fn-Fs);if(s->ap[k]<=1e-30)s->ap[k]=1e-30;s->b[k]=srcvar(var,xx,yy,st)*vol;if(BENCH_ID=='B')s->b[k]-=(var=='u'?mms_pdx(xx,yy,st):mms_pdy(xx,yy,st))*vol; (void)rho;(void)ua;(void)va;(void)dif; }
}
static double residual(Sys*s){double r2=0,b2=0;int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2) reduction(+:r2,b2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];double r=s->b[k]-Aq;r2+=r*r;b2+=s->b[k]*s->b[k];}return sqrt(r2/(b2+1e-300));}
static void rbgs(Sys*s,int sweeps){int nx=s->nx,ny=s->ny;for(int it=0;it<sweeps;it++)for(int c=0;c<2;c++){
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++)if(((i+j)&1)==c){int k=IDX(i,j,nx);s->q[k]=(s->b[k]+s->ae[k]*s->q[k+1]+s->aw[k]*s->q[k-1]+s->an[k]*s->q[k+nx]+s->as[k]*s->q[k-nx])/s->ap[k];}}}
static void smooth_correction(Sys*s,int stride,int repeats,double omega){int nx=s->nx,ny=s->ny;double *corr=calloc((size_t)nx*ny,sizeof(double));if(!corr)die("corr");for(int rep=0;rep<repeats;rep++){memset(corr,0,(size_t)nx*ny*sizeof(double));
 #pragma omp parallel for collapse(2)
 for(int j=stride;j<ny-1;j+=stride)for(int i=stride;i<nx-1;i+=stride){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];corr[k]=(s->b[k]-Aq)/s->ap[k];}
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int ic=(i/stride)*stride,jc=(j/stride)*stride;if(ic<1)ic=stride;if(jc<1)jc=stride;if(ic>=nx-1)ic=nx-1-stride;if(jc>=ny-1)jc=ny-1-stride;s->q[IDX(i,j,nx)]+=omega*corr[IDX(ic,jc,nx)];}}
 free(corr);}

static double *residual_array(Sys *s){
 size_t n=(size_t)s->nx*s->ny; double *r=calloc(n,sizeof(double)); if(!r)die("residual alloc"); int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];r[k]=s->b[k]-Aq;}return r;
}
static void correction_bc_zero(Sys*s){int nx=s->nx,ny=s->ny;for(int i=0;i<nx;i++){s->q[IDX(i,0,nx)]=0;s->q[IDX(i,ny-1,nx)]=0;}for(int j=0;j<ny;j++){s->q[IDX(0,j,nx)]=0;s->q[IDX(nx-1,j,nx)]=0;}}
static void make_coarse(Sys*f,Sys*c,int ratio){int nx=f->nx/ratio,ny=f->ny/ratio;if(nx<5)nx=5;if(ny<5)ny=5;allocsys(c,nx,ny);assemble(c,f->var,f->st);memset(c->b,0,(size_t)nx*ny*sizeof(double));memset(c->q,0,(size_t)nx*ny*sizeof(double));correction_bc_zero(c);}
static void restrict_2x2_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=2*i-1,j0=2*j-1;if(i0+1<f->nx-1&&j0+1<f->ny-1)c->b[IDX(i,j,c->nx)]=.25*(r[IDX(i0,j0,f->nx)]+r[IDX(i0+1,j0,f->nx)]+r[IDX(i0,j0+1,f->nx)]+r[IDX(i0+1,j0+1,f->nx)]);}}
static double cv(Sys*c,int i,int j){if(i<0||j<0||i>=c->nx||j>=c->ny)return 0.0;return c->q[IDX(i,j,c->nx)];}
static void prolong_2to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int il=2*i-1,ir=2*i,jb=2*j-1,jt=2*j;if(ir>=f->nx-1||jt>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(il,jb,f->nx)]+=.5625*cc+.1875*cw+.1875*cs+.0625*csw;f->q[IDX(ir,jb,f->nx)]+=.5625*cc+.1875*ce+.1875*cs+.0625*cse;f->q[IDX(il,jt,f->nx)]+=.5625*cc+.1875*cw+.1875*cn+.0625*cnw;f->q[IDX(ir,jt,f->nx)]+=.5625*cc+.1875*ce+.1875*cn+.0625*cne;}}
static void restrict_3x3_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=3*i-2,j0=3*j-2;double z=0;int cnt=0;for(int dj=0;dj<3;dj++)for(int di=0;di<3;di++)if(i0+di>0&&j0+dj>0&&i0+di<f->nx-1&&j0+dj<f->ny-1){z+=r[IDX(i0+di,j0+dj,f->nx)];cnt++;}c->b[IDX(i,j,c->nx)]=cnt?z/cnt:0;}}
static void prolong_3to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int iL=3*i-2,iC=3*i-1,iR=3*i,jB=3*j-2,jC=3*j-1,jT=3*j;if(iR>=f->nx-1||jT>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(iL,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*cw;f->q[IDX(iC,jC,f->nx)]+=cc;f->q[IDX(iR,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*ce;f->q[IDX(iL,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cs+(1.0/9)*csw;f->q[IDX(iC,jB,f->nx)]+=(2.0/3)*cc+(1.0/3)*cs;f->q[IDX(iR,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cs+(1.0/9)*cse;f->q[IDX(iL,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cn+(1.0/9)*cnw;f->q[IDX(iC,jT,f->nx)]+=(2.0/3)*cc+(1.0/3)*cn;f->q[IDX(iR,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cn+(1.0/9)*cne;}}
static void mg_cycle_ref(Sys*s,int ratio,int levels,int visits){rbgs(s,3);double*r=residual_array(s);Sys c;make_coarse(s,&c,ratio);if(ratio==2)restrict_2x2_ref(s,r,&c);else restrict_3x3_ref(s,r,&c);free(r);if(levels>1&&c.nx>=10&&c.ny>=10){for(int q=0;q<visits;q++)mg_cycle_ref(&c,ratio,levels-1,visits);}else rbgs(&c,40);if(ratio==2)prolong_2to1_ref(&c,s);else prolong_3to1_ref(&c,s);freesys(&c);rbgs(s,3);}
/* This audit keeps the local V2 numerical kernels unchanged.
   The older damping/fallback variant is archived separately in history/github_v2. */

/* V2: production-structure RMT. The error equation recursively receives the same
   factor-three, 3x3 shifted-family treatment; it does not terminate each shifted
   grid immediately in a direct coarse RBGS solve as V1 did. */

/* Production-aligned RMT benchmark adaptation.
   Invariants intentionally matched to the reacting-flow pressure RMT:
     - factor-three, 3x3 shifted coarse families;
     - no presmoothing;
     - control-volume averaging of the correction defect;
     - direct solve on every coarsest shifted grid;
     - coarsest-to-finest post-smoothing;
     - full correction added without interpolation;
     - one globally fixed 16-sweep postsmoothing count;
     - no damping, monotonic line search, rollback, or hidden fallback.
   The MMS benchmark uses homogeneous Dirichlet correction traces, whereas the
   opposed-flow pressure solver uses its production mixed correction BCs. */

static void rmt_direct_dense(Sys*s){
    const int ni=s->nx-2,nj=s->ny-2,n=ni*nj;
    if(n<=0)return;
    double *A=calloc((size_t)n*(size_t)n,sizeof(double));
    double *b=calloc((size_t)n,sizeof(double));
    if(!A||!b)die("RMT direct allocation");

    for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++){
        const int k=IDX(i,j,s->nx);
        const int row=(j-1)*ni+(i-1);
        A[(size_t)row*n+row]=s->ap[k];
        b[row]=s->b[k];
        if(i>1)       A[(size_t)row*n+(row-1)] = -s->aw[k];
        if(i<s->nx-2) A[(size_t)row*n+(row+1)] = -s->ae[k];
        if(j>1)       A[(size_t)row*n+(row-ni)] = -s->as[k];
        if(j<s->ny-2) A[(size_t)row*n+(row+ni)] = -s->an[k];
    }

    for(int k=0;k<n;k++){
        int piv=k;
        double vmax=fabs(A[(size_t)k*n+k]);
        for(int r=k+1;r<n;r++){
            double v=fabs(A[(size_t)r*n+k]);
            if(v>vmax){vmax=v;piv=r;}
        }
        if(vmax<1e-30)die("RMT direct singular coarsest system");
        if(piv!=k){
            for(int c=k;c<n;c++){
                double t=A[(size_t)k*n+c];
                A[(size_t)k*n+c]=A[(size_t)piv*n+c];
                A[(size_t)piv*n+c]=t;
            }
            double tb=b[k];b[k]=b[piv];b[piv]=tb;
        }
        const double akk=A[(size_t)k*n+k];
        for(int r=k+1;r<n;r++){
            const double m=A[(size_t)r*n+k]/akk;
            if(m==0.0)continue;
            A[(size_t)r*n+k]=0.0;
            for(int c=k+1;c<n;c++)A[(size_t)r*n+c]-=m*A[(size_t)k*n+c];
            b[r]-=m*b[k];
        }
    }

    for(int r=n-1;r>=0;r--){
        double z=b[r];
        for(int c=r+1;c<n;c++)z-=A[(size_t)r*n+c]*b[c];
        b[r]=z/A[(size_t)r*n+r];
    }

    for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++){
        const int row=(j-1)*ni+(i-1);
        s->q[IDX(i,j,s->nx)]=b[row];
    }
    correction_bc_zero(s);
    free(A);free(b);
}

static void rmt_error_recursive(Sys*s,int level){
    if(level>=5 || s->nx<12 || s->ny<8){
        rmt_direct_dense(s);
        return;
    }

    double*r=residual_array(s);
    for(int sy=0;sy<3;sy++)for(int sx=0;sx<3;sx++){
        Sys c; make_coarse(s,&c,3);
        for(int jc=1;jc<c.ny-1;jc++)for(int ic=1;ic<c.nx-1;ic++){
            const int i0=sx+1+3*(ic-1),j0=sy+1+3*(jc-1);
            int ilo=i0-1,ihi=i0+1,jlo=j0-1,jhi=j0+1;
            if(ilo<1)ilo=1;if(jlo<1)jlo=1;
            if(ihi>s->nx-2)ihi=s->nx-2;
            if(jhi>s->ny-2)jhi=s->ny-2;
            double sum=0.0;int cnt=0;
            for(int fj=jlo;fj<=jhi;fj++)for(int fi=ilo;fi<=ihi;fi++){
                sum+=r[IDX(fi,fj,s->nx)];
                cnt++;
            }
            c.b[IDX(ic,jc,c.nx)]=cnt?sum/(double)cnt:0.0;
        }
        correction_bc_zero(&c);
        rmt_error_recursive(&c,level+1);

        /* Index-space transfer: each shifted family writes directly to the
           corresponding fine-grid locations; no interpolation is used. */
        for(int jc=1;jc<c.ny-1;jc++)for(int ic=1;ic<c.nx-1;ic++){
            const int fi=sx+1+3*(ic-1),fj=sy+1+3*(jc-1);
            if(fi>0&&fj>0&&fi<s->nx-1&&fj<s->ny-1)
                s->q[IDX(fi,fj,s->nx)] += c.q[IDX(ic,jc,c.nx)];
        }
        freesys(&c);
    }
    free(r);

    /* Single global smoothing choice, matched to the calibrated production RMT. */
    rbgs(s,16);
}

static void rmt_cycle_ref(Sys*s){
    size_t n=(size_t)s->nx*s->ny;
    double*r=residual_array(s);
    Sys corr; make_coarse(s,&corr,1);
    for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)
        corr.b[IDX(i,j,corr.nx)] = r[IDX(i,j,s->nx)];
    correction_bc_zero(&corr);

    rmt_error_recursive(&corr,0);

    /* Full correction: no damping and no residual-dependent acceptance test. */
    for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)
        s->q[IDX(i,j,s->nx)] += corr.q[IDX(i,j,corr.nx)];

    freesys(&corr);
    free(r);
    (void)n;
}


static int solve(Sys*s,const char*solver,double tol,int maxit){
    int it=0;
    while(it<maxit){
        double r=residual(s);
        if(!isfinite(r)||r<=tol)break;
        if(strcmp(solver,"SG_RBGS")==0){
            int sweeps=(maxit-it>=2)?2:1;
            rbgs(s,sweeps); it+=sweeps;
        }else{
            if(strcmp(solver,"MG2V")==0) mg_cycle_ref(s,2,2,1);
            else if(strcmp(solver,"MG2W")==0) mg_cycle_ref(s,2,2,2);
            else if(strcmp(solver,"MG3V")==0) mg_cycle_ref(s,3,2,1);
            else rmt_cycle_ref(s);
            it+=1;
            /* Preserve the local V2 residual-evaluation workload. */
            if(!isfinite(residual(s)))break;
        }
    }
    return it;
}
static void norms(Sys*s,double*L1,double*L2,double*Li){double a=0,b=0,c=0;size_t n=(size_t)s->nx*s->ny;
 #pragma omp parallel for reduction(+:a,b) reduction(max:c)
 for(long long k=0;k<(long long)n;k++){double e=fabs(s->q[k]-s->exact[k]);a+=e;b+=e*e;if(e>c)c=e;}*L1=a/n;*L2=sqrt(b/n);*Li=c;}
static void init_zero(Sys*s){for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)s->q[IDX(i,j,s->nx)]=0.0;}
static int finite_sources(int st){for(int j=0;j<9;j++)for(int i=0;i<17;i++){double xx=3.0*i/16.0,yy=j/8.0;double vals[8]={mms_rho(xx,yy,st),mms_diff(xx,yy,st),srcvar('f',xx,yy,st),srcvar('o',xx,yy,st),srcvar('p',xx,yy,st),srcvar('u',xx,yy,st),srcvar('v',xx,yy,st),srcvar('h',xx,yy,st)};for(int k=0;k<8;k++)if(!isfinite(vals[k]))return 0;}return 1;}



typedef struct {double l1,l2,li,t,r;int it;const char *status;} VR;
static int valid_solver(const char *s){
    return !strcmp(s,"SG_RBGS")||!strcmp(s,"MG2V")||!strcmp(s,"MG2W")||
           !strcmp(s,"MG3V")||!strcmp(s,"RMT3H");
}
static int parse_int(const char *s){
    char *end; errno=0; long v=strtol(s,&end,10);
    if(errno||!*s||*end||v<1||v>INT_MAX)die("invalid positive integer");
    return (int)v;
}
static double parse_tol(const char *s){
    char *end; errno=0; double v=strtod(s,&end);
    if(errno||!*s||*end||!isfinite(v)||v<=0||v>=1)die("invalid tolerance");
    return v;
}
static int reached(double r,double tol){return isfinite(r)&&r>=0&&r<=tol;}
static void one_species(int nx,int ny,int st,char var,const char *solver,
                        double tol,int maxit,VR *o,const char *fieldout){
    Sys s; allocsys(&s,nx,ny); assemble(&s,var,st); init_zero(&s);
    double t=wall(); o->it=solve(&s,solver,tol,maxit); o->t=wall()-t;
    o->r=residual(&s); norms(&s,&o->l1,&o->l2,&o->li);
    if(!isfinite(o->r)||!isfinite(o->l1)||!isfinite(o->l2)||!isfinite(o->li))
        o->status="NONFINITE";
    else if(reached(o->r,tol))o->status="CONVERGED";
    else if(o->it>=maxit)o->status="ITERATION_LIMIT";
    else o->status="STOPPED";
    if(fieldout){
        FILE *f=fopen(fieldout,"w"); if(!f)die("field output");
        fprintf(f,"x,y,variable,exact,numerical,error\n");
        for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){
            int k=IDX(i,j,nx); double ex=s.exact[k],q=s.q[k];
            fprintf(f,"%.17g,%.17g,YF,%.17g,%.17g,%.17g\n",i*s.dx,j*s.dy,ex,q,q-ex);
        }
        if(fclose(f))die("field output close");
    }
    freesys(&s);
}
int main(int argc,char **argv){
    int nx=108,ny=36,st=1,maxit=240000,requested=omp_get_max_threads();
    double tol=1e-7; const char *solver="SG_RBGS",*out="case_summary.csv",*fieldout=NULL;
    for(int a=1;a<argc;a++){
        if(a+1>=argc)die("option requires a value");
        const char *option=argv[a],*value=argv[++a];
        if(!strcmp(option,"--Nx"))nx=parse_int(value);
        else if(!strcmp(option,"--Ny"))ny=parse_int(value);
        else if(!strcmp(option,"--stiffness")){
            if(strlen(value)!=2||value[0]!='S'||value[1]<'1'||value[1]>'3')die("invalid stiffness");
            st=value[1]-'0';
        }else if(!strcmp(option,"--solver"))solver=value;
        else if(!strcmp(option,"--out"))out=value;
        else if(!strcmp(option,"--field-out"))fieldout=value;
        else if(!strcmp(option,"--tol"))tol=parse_tol(value);
        else if(!strcmp(option,"--max-iter"))maxit=parse_int(value);
        else if(!strcmp(option,"--expected-threads"))requested=parse_int(value);
        else die("unknown option");
    }
    if(nx<12||ny<8||nx>INT_MAX/ny||maxit>INT_MAX/3||!valid_solver(solver))die("invalid grid, solver or iteration cap");
    if(BENCH_ID!='C')die("this audited executable is Benchmark C only");
    omp_set_dynamic(0); int actual=0;
    #pragma omp parallel
    {
        #pragma omp single
        actual=omp_get_num_threads();
    }
    if(actual!=requested)die("actual OpenMP team differs from requested threads");
    if(!finite_sources(st))die("nonfinite MMS source");
    VR v[3]={{0}}; const char vars[3]={'f','o','p'};
    double max1=0,max2=0,maxi=0,rr=0,tot=0;int its=0,converged=1,finite=1;
    for(int z=0;z<3;z++){
        one_species(nx,ny,st,vars[z],solver,tol,maxit,&v[z],z==0?fieldout:NULL);
        if(strcmp(v[z].status,"CONVERGED"))converged=0;
        if(!strcmp(v[z].status,"NONFINITE"))finite=0;
        max1=fmax(max1,v[z].l1);max2=fmax(max2,v[z].l2);maxi=fmax(maxi,v[z].li);
        rr=fmax(rr,v[z].r); tot+=v[z].t; its+=v[z].it;
    }
    if(!finite){max1=NAN;max2=NAN;maxi=NAN;rr=NAN;}
    FILE *f=fopen(out,"w");if(!f)die("summary output");
    fprintf(f,"benchmark,stiffness,Nx,Ny,threads,solver,converged,iterations,relative_residual,L1,L2,Linf,solve_wall_time,total_relevant_wall_time,continuity_metric,p_L2,u_L2,v_L2,YF_L2,YO_L2,YP_L2,h_L2,T_L2,rho_L2,T_rel_L2,rho_rel_L2\n");
    fprintf(f,"C,S%d,%d,%d,%d,%s,%d,%d,%.12e,%.12e,%.12e,%.12e,%.9f,%.9f,0,0,0,0,%.12e,%.12e,%.12e,0,0,0,0,0\n",
        st,nx,ny,actual,solver,converged,its,rr,max1,max2,maxi,tot,tot,
        v[0].l2,v[1].l2,v[2].l2);
    if(fclose(f))die("summary output close");
    printf("BENCH=C solver=%s threads=%d residual=%.3e converged=%d time=%.6f\n",
           solver,actual,rr,converged,tot);
    return converged?0:3;
}

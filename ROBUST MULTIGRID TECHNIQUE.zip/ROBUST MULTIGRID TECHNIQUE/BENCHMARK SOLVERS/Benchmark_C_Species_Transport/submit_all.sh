#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p logs
[[ -x build/mms_solver ]] || { echo "Run bash build.sh first" >&2; exit 2; }
sha256sum --check --status build/SHA256SUMS
python3 campaign.py check
# Prevent accidentally submitting the same full array a second time.
if [[ -e logs/submission_job_id.txt ]]; then
    echo "This extraction has already been submitted. Job: $(cat logs/submission_job_id.txt)" >&2
    echo "Check that job before submitting anything again." >&2
    exit 2
fi
job=$(sbatch --parsable benchmark_C_array.slurm)
printf '%s\n' "$job" > logs/submission_job_id.txt
echo "Submitted job $job: Orfoz, 60 groups x 5 solvers = 300 cases, ONE repeat, %3."

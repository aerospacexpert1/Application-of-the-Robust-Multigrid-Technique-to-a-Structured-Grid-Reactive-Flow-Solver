#!/usr/bin/env python3
from campaign import collect
if __name__ == '__main__':
    collect()

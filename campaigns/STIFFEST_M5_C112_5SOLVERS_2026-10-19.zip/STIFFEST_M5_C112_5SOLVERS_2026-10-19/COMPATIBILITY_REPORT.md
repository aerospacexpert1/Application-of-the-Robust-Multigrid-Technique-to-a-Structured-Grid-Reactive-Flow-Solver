# C112 compatibility audit

Five in-house production solvers; frozen numerical sources are unchanged.

| Solver | Archived source SHA256 | Pressure limit | Original method |
|---|---|---:|---|
| SG_RBGS | 4b56b1b169500d307d44e49ef26290ba2e40efb604b1bebf504b3a6f2eddb1db | 500000 | SG_RBGS |
| MG2V | e597ce49edc4f9281ec7dab93a239c89030eb35b143ae22daf091e47140d0cf0 | 500 | MG2V_3LEVEL |
| MG2W | 576e8d35ff3cf2e6ec5167110a9ce29fe6422ea8657c24091128404c642b20f5 | 500 | MG2W_3LEVEL |
| MG3V | c62c778fb2baba315f99ec79869214c741ca2f37dbca0692309ec5d434627c50 | 500 | MG3V_3LEVEL |
| RMT | 4b56b1b169500d307d44e49ef26290ba2e40efb604b1bebf504b3a6f2eddb1db | 500 | RMT_FINALVOL2 |

All original SG/MG96 manifests match before thread-label conversion. RMT uses the same original generated matrix. The only matrix changes are the thread level and its labels. Source .c/.h hashes match the public archive exactly.

Seven non-pressure kernels match after excluding comments and whitespace: momentum predictor, pressure RHS construction, velocity/flux correction, scalar RHS, scalar Helmholtz sweeps, chemistry subcycling, and thermophysical update.

The timestep loop is inspected separately: MG changes are pressure work statistics and pressure-solver calls; the source algorithms are not unified or retuned. Per-method pressure caps retain their original units. The runner environment pins existing defaults.

Runtime launch is gated on Orfoz build, original RMT self-tests, and actual OpenMP team112. No additional application smoke cases are scheduled. These gates have not been run locally on Linux. Full campaign convergence and high-core speedups remain measured outcomes.

The previously delivered two-solver ZIP remains unchanged. No jobs were submitted from this workspace.

User-restricted pilot: exactly five application runs, all S3_HIGH_A1e9_Ta100 / M5_1728x576 / C112. Source hashes and original solver settings remain unchanged. No other physical cases, meshes or thread levels are in the production manifest.

## Authorized refinement extension (2026-10-19)

Exactly five S3_HIGH application runs, mesh1728x576, C112, one measurement each. The mesh has995328 cells, four times the previous248832. Per-task Slurm wall limit is24h; no solver/tolerance/physics tuning or extra application smoke cases.

All source .c/.h bytes and all five archived run_case.sh launchers are identical to the successfully used M4 package. GCC/module/flags, timestep controls, final physical time2s, pressure tolerances, cap500 cycles (SG500000 sweeps), relaxation and scalar sweeps are unchanged. MG2V's previous single above-target pressure step is not hidden by increasing caps or relaxing tolerances.

Mesh divisibility:1728 and576 are divisible by4 and9; the existing MG2 and MG3 three-level hierarchies remain valid. RMT keeps its original automatic hierarchy and nCoarsest5 policy; its hierarchy grows naturally with refinement. Geometry QA checks the existing level/direct-block limits without editing them.

Real Linux/GCC and112-core CFD runtime verification occurs on TRUBA. LOCAL_QA.json distinguishes local source/generation/launcher/collector tests from actual CFD execution. This package does not claim that a24h wall limit guarantees convergence or completion.

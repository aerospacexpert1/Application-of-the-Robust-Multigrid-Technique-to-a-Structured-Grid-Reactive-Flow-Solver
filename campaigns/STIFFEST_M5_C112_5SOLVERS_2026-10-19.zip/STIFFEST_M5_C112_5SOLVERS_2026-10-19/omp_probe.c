#include <omp.h>
#include <stdio.h>
int main(void) {
    int actual=0;
    omp_set_dynamic(0); omp_set_num_threads(112);
    #pragma omp parallel
    {
        #pragma omp single
        actual=omp_get_num_threads();
    }
    printf("OPENMP_PROBE requested=112 actual=%d\n", actual);
    return actual==112 ? 0 : 1;
}

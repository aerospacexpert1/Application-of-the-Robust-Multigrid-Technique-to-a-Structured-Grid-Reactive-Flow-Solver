#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
case "$(pwd -P)/" in
  /arf/scratch/*/) ;;
  *) echo 'ERROR: extract and submit under /arf/scratch/' >&2; exit 2 ;;
esac
python3 campaign.py check
mkdir -p logs
build_id=$(sbatch --parsable build_112.slurm)
build_id=${build_id%%;*}
[[ "$build_id" =~ ^[0-9]+$ ]] || { echo 'Invalid build job ID' >&2; exit 3; }
echo "Build job: $build_id"
array_id=$(sbatch --parsable --dependency="afterok:$build_id" campaign_112.slurm)
array_id=${array_id%%;*}
echo "Campaign array: $array_id (5 tasks; 112 threads; one task at a time)"
printf '%s,%s,%s\n' "$(date --iso-8601=seconds)" "$build_id" "$array_id" >> submission_history.csv

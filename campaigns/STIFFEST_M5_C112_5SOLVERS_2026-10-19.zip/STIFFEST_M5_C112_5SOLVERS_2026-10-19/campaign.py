#!/usr/bin/env python3
"""112-thread five-solver campaign: 5 planned rows, one measurement each."""
import argparse, collections, csv, hashlib, json, math, os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT/'campaign_config.json').read_text())
SOLVERS = {k:v['label'] for k,v in CONFIG['solvers'].items()}

def manifest():
    with (ROOT/'campaign_manifest.csv').open(newline='') as f:
        return list(csv.DictReader(f))

def run_dir(m):
    p = ROOT/'solvers'/m['solver_key']/'results'/m['group_dir']/m['physical_case']/m['mesh_name']/m['core_label']
    assert p.resolve().is_relative_to(ROOT.resolve())
    return p

def kv(path):
    if not path.exists(): return {}
    return dict(line.split('=', 1) for line in path.read_text(errors='replace').splitlines() if '=' in line)

def number(row, key):
    x = float(row[key])
    if not math.isfinite(x): raise ValueError(f'Non-finite {key}')
    return x

def validate(m):
    """Completion includes metadata, final residual and every recorded pressure solve."""
    d = run_dir(m); path = d/'output/summary.csv'; data = {}; reason = ''
    timing = kv(d/'launcher_timing.txt')
    if not path.exists():
        status = 'FAILED' if (d/'RUN_FAILED').exists() else 'RUNNING_OR_INCOMPLETE' if (d/'run.log').exists() else 'MISSING'
        return status, data, reason
    try:
        with path.open(newline='') as f: records = list(csv.DictReader(f))
        if len(records) != 1: raise ValueError('Expected one summary record')
        data = records[0]
        for k in ('case_id', 'Nx', 'Ny', 'threads'):
            if data[k] != m[k]: raise ValueError(f'{k} does not match manifest')
        if data['solver'] != SOLVERS[m['solver_key']]: raise ValueError('Solver label mismatch')
        if abs(number(data, 'final_time_s')-2.0) > 2e-11: raise ValueError('Final physical time is not 2 s')
        for k in ('compute_time_s', 'pressure_time_s'):
            if number(data, k) <= 0: raise ValueError(f'Invalid timing: {k}')
        for k in ('Tmax_K', 'mass_residual_max'): number(data, k)
        for k in ('YFmax', 'YOmax', 'YPmax', 'YN2max'):
            if not -1e-10 <= number(data, k) <= 1.00001: raise ValueError(f'Invalid {k}')
        for p in ('fields.pvd', 'performance/final_pressure_cycle_history.csv'):
            if not (d/'output'/p).is_file() or not (d/'output'/p).stat().st_size:
                raise ValueError(f'Missing output: {p}')
        # Check numerical convergence before interpreting legacy completion markers.
        if timing.get('exit_code') != '0':
            return 'FAILED' if (d/'RUN_FAILED').exists() else 'RUNNING_OR_INCOMPLETE', data, 'Execution is not complete'
        text = (d/'run.log').read_text(errors='replace')
        if not any(x.startswith('Done.') for x in text.splitlines()): raise ValueError('Missing Done marker')
        if m['solver_key'] == 'RMT' and 'RMT_FINALVOL2_DIAGNOSTICS' not in text:
            raise ValueError('Missing RMT diagnostics')
        rel = number(data, 'final_pressure_rel_residual'); ab = number(data, 'final_pressure_abs_residual')
        converged = (0 <= rel <= (1e-4*(1+1e-10)) or 0 <= ab <= (1e-6*(1+1e-10)))
        failed_steps = 0; steps = 0
        with (d/'output/performance/pressure_step_history.csv').open(newline='') as f:
            for h in csv.DictReader(f):
                steps += 1
                r = number(h, 'final_relative_residual'); a = number(h, 'final_residual')
                if not (0 <= r <= (1e-4*(1+1e-10)) or 0 <= a <= (1e-6*(1+1e-10))): failed_steps += 1
        if not steps: raise ValueError('Empty pressure history')
        if steps != int(number(data, 'time_steps')): raise ValueError('Truncated pressure history')
        data['pressure_steps_above_target'] = str(failed_steps)
        if not converged or failed_steps or 'RMT_PRESSURE_NOT_CONVERGED' in text:
            return 'NONCONVERGED', data, f'Pressure target unmet; recorded steps above target={failed_steps}'
        if not (d/'RUN_COMPLETE').exists():
            return 'FAILED' if (d/'RUN_FAILED').exists() else 'RUNNING_OR_INCOMPLETE', data, 'Completion marker missing'
        return 'COMPLETE', data, ''
    except (KeyError, ValueError, OSError, StopIteration, csv.Error) as e:
        return 'INVALID', data, str(e)

def check():
    rows = manifest()
    assert len(rows) == 5
    assert [int(r['task_id']) for r in rows] == list(range(5))
    assert collections.Counter(r['solver_key'] for r in rows) == {k:1 for k in SOLVERS}
    assert collections.Counter(r['group_dir'] for r in rows) == {'STIFFNESS':5}
    assert {r['threads'] for r in rows} == {'112'}
    assert {r['physical_case'] for r in rows} == {'S3_HIGH_A1e9_Ta100'}
    assert {(int(r['Nx']), int(r['Ny'])) for r in rows} == {(1728,576)}
    assert len({(r['solver_key'],r['case_id']) for r in rows}) == 5
    for solver in SOLVERS:
        with (ROOT/'solvers'/solver/'campaign_manifest.csv').open(newline='') as f:
            local = list(csv.DictReader(f))
        assert len(local) == 1
        for r in [x for x in rows if x['solver_key']==solver]:
            assert all(local[int(r['local_index'])][k] == v for k,v in r.items()
                       if k not in ('task_id','solver_key','local_index'))
    p = json.loads((ROOT/'PROVENANCE.json').read_text())
    for rel, digest in p['upstream_files'].items():
        expected = p['modified_launchers'].get(rel, {}).get('new_sha256', digest)
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest() == expected, rel
    print('CHECK PASS: Five solvers x1; S3_HIGH, M5_1728x576; C112 only; one measurement per configuration.')

def collect():
    out = []; counts = collections.Counter()
    for m in manifest():
        status, data, reason = validate(m); counts[status] += 1
        r = dict(m)
        # Keep manifest metadata authoritative; retain solver-specific output fields.
        r.update({k:v for k,v in data.items() if k not in r})
        r.update(status=status, validation_note=reason, run_dir=str(run_dir(m).relative_to(ROOT)))
        params = kv(run_dir(m)/'parameters.txt')
        r['node'] = params.get('node',''); r['job_id'] = params.get('job_id','')
        timing = kv(run_dir(m)/'launcher_timing.txt')
        r['launcher_wall_seconds'] = next((v for k,v in timing.items() if k.startswith('launcher_wall_seconds')), '')
        out.append(r)
    outputs = [('C112_campaign_summary.csv',out)]
    outputs += [(key+'_C112_campaign_summary.csv',[r for r in out if r['solver_key']==key]) for key in SOLVERS]
    for filename, selected in outputs:
        target = ROOT/filename
        if target.exists():
            old = target.read_bytes(); digest = hashlib.sha256(old).hexdigest()
            backup = ROOT/'summary_history'/f'{target.stem}_{digest}.csv'
            backup.parent.mkdir(exist_ok=True)
            if not backup.exists(): backup.write_bytes(old)
        fields = list(dict.fromkeys(k for r in selected for k in r))
        with target.open('w',newline='') as f:
            w = csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(selected)
    print(json.dumps(dict(counts),indent=2)); print('5 planned rows -> C112_campaign_summary.csv')

def run(index):
    rows = manifest()
    if not 0 <= index < len(rows): raise SystemExit('Task index must be 0..4')
    m = rows[index]; d = run_dir(m)
    if not os.environ.get('SLURM_JOB_ID'): raise SystemExit('Submit through Slurm; do not run solvers on the login node.')
    if int(os.environ.get('SLURM_CPUS_PER_TASK','0')) != 112:
        raise SystemExit('This package requires cpus-per-task=112')
    if int(os.environ.get('SLURM_JOB_NUM_NODES','1')) != 1:
        raise SystemExit('This package requires exactly one node')
    status, _, reason = validate(m)
    if status == 'COMPLETE': print('SKIP verified complete:', m['solver_key'],m['case_id']); return
    if d.exists() and any(d.iterdir()):
        raise SystemExit(f'Existing incomplete/failed output preserved: {d}. Move this case directory aside before retrying.')
    sub = ROOT/'solvers'/m['solver_key']
    env = os.environ.copy(); env['ROOT'] = str(sub)
    env.update(END_TIME='2.0', WRITE_INTERVAL='2.0', DT0='1e-7', DTMAX='1e-4',
               PROGRESS_EVERY='1000', RHO0='1.0', MU0='2.0e-5', CP0='1000.0',
               PR0='0.7', SC0='1.0', HFF='3.571428571e6', P_CYCLES='500',
               P_REL_TOL='1e-4', P_ABS_TOL='1e-6', RMT_LEVELS='0',
               RMT_SMOOTH_SWEEPS='16', RMT_OMEGA='1.0', MG_PRE='3',
               MG_POST='3', MG_COARSE_SWEEPS='40', MG_OMEGA='1.0',
               P_SWEEPS='500000', RBGS_OMEGA='1.0',
               OMP_NUM_THREADS='112', OMP_THREAD_LIMIT='112', OMP_DYNAMIC='false',
               OMP_PROC_BIND='close', OMP_PLACES='cores')
    print(f"TASK {index}: {m['solver_key']} {m['case_id']}",flush=True)
    d.mkdir(parents=True,exist_ok=True)
    metadata = {'solver_key':m['solver_key'],'task_id':index,'requested_threads':112,
                'job_id':os.environ['SLURM_JOB_ID'],'node':os.environ.get('SLURMD_NODENAME',''),
                'executable_sha256':hashlib.sha256((sub/'build'/CONFIG['solvers'][m['solver_key']]['binary']).read_bytes()).hexdigest(),
                'frozen_environment':{k:env[k] for k in ('END_TIME','DT0','DTMAX','P_CYCLES','P_SWEEPS','P_REL_TOL','P_ABS_TOL','OMP_NUM_THREADS','OMP_PROC_BIND','OMP_PLACES')}}
    (d/'execution_provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
    rc = subprocess.call(['bash',str(sub/'run_case.sh'),m['local_index']],cwd=sub,env=env)
    status, _, reason = validate(m)
    print('VALIDATION:',status,reason,flush=True)
    if rc or status != 'COMPLETE': raise SystemExit(rc or 20)

def main():
    p = argparse.ArgumentParser(); sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('check'); sub.add_parser('collect')
    r=sub.add_parser('run-case'); r.add_argument('index',type=int)
    a=p.parse_args()
    if a.command=='check': check()
    elif a.command=='collect': collect()
    else: run(a.index)
if __name__ == '__main__': main()

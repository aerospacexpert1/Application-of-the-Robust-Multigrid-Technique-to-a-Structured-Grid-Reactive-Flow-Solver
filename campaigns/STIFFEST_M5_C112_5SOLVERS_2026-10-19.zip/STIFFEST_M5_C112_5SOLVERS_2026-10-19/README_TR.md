# S3 / 1728×576 / 112 thread — 5 çözücü

Toplam **5 production koşusu**, her çözücü bir kez. RMT, MG2-V, MG2-W, MG3-V, SG-RBGS sırasıyla; hepsi S3_HIGH_A1e9_Ta100, M5_1728x576, C112. OpenFOAM dahil değildir. Ek case/mesh/thread seviyesi veya otomatik tekrar yoktur.

Mesh995328 hücre içerir; önceki864×288 mesh'in dört katıdır. Domain/fizik aynı; her yönde çözünürlük iki katıdır. Eski M4 kaynak ve sonuçları korunur; bu paket ayrı klasör ve ayrı M5 etiketleri kullanır.

## TRUBA'da başlatma

ZIP'i GitHub'dan indirip /arf/scratch/ozayifoglu altında yeni klasöre açın:

```bash
cd /arf/scratch/ozayifoglu
unzip STIFFEST_M5_C112_5SOLVERS_2026-10-19.zip
cd STIFFEST_M5_C112_5SOLVERS_2026-10-19
sha256sum -c SHA256SUMS.txt
bash submit_all.sh
```

submit_all.sh önce Orfoz'da derlemeyi gönderir; GCC12.3.0 ile beş binary derlenir, özgün RMT self-test/fairness/equivalence kontrolleri ve gerçek112-thread probe'u geçerse production array başlar. Derleme limiti1 saat; her production task limiti**24 saat**. Tek düğüm, ntasks1, cpus-per-task112, exclusive; array0-4%1 ile aynı anda bir çözücü çalışır.

Başlatma komutunu bir kez kullanın. Tekrar submit yeni Slurm işleri yaratır. Doğrulanmış tamamlanmış case'ler atlanır; yarım/başarısız çıktı klasörleri otomatik silinmez. Mevcut kodda checkpoint/restart akışı kurulmadığından wall-time sınırında kalan koşu final sonuç olarak kabul edilmez.

```bash
squeue -u "$USER"
python3 collect_summary.py
```

C112_campaign_summary.csv toplam5 planlı satır içerir. Ayrıca her çözücü için ayrı summary oluşur. COMPLETE/NONCONVERGED/INVALID/FAILED/RUNNING_OR_INCOMPLETE/MISSING ayrıdır. Final hedef sağlansa bile önceki bir pressure solve hedefi aşmışsa NONCONVERGED gösterilir. Kaydedilen pressure-step sayısı time_steps ile eşleşmek zorundadır. Eski summary'ler hash isimli summary_history kopyasıyla korunur.

## Değişmeyen ayarlar

- S3: giriş hızı0.1 m/s, A1e9, beta5, Ta100 K; son fiziksel zaman2 s.
- dt0=1e-7, dtMax=1e-4; özgün maxCo0.05/maxDi0.45 ve adaptif timestep korunur.
- Pressure relTol1e-4/absTol1e-6; multilevel max500 cycle, SG max500000 sweep.
- RMT FINALVOL2: mevcut otomatik hiyerarşi, smoothing16, omega1; Improved RMT değildir.
- MG2-V/W: özgün üç seviye h/2h/4h; MG3-V h/3h/9h; pre/post3/3, coarse40, omega1.
- Scalar cycles4/sweeps5, mevcut relaxation; rho1, mu2e-5, cp1000, Pr0.7, Sc1, HfF3.571428571e6; perfectGas0, variableCp0, sutherland0, rhoRelax1.
- OMP_NUM_THREADS112, OMP_THREAD_LIMIT112, OMP_DYNAMICfalse, OMP_PROC_BINDclose, OMP_PLACEScores.

Bütün .c/.h ve run_case.sh dosyaları M4 paketinden byte-identical alınmıştır. PROVENANCE.json upstream ve parent hash'lerini, COMPATIBILITY_REPORT.md uyumluluk denetimini içerir. İki kat lineer refinement fiziksel adım sayısını da artırabilir; süre tahmini ölçüm değildir.24 saat sınırı koşu tamamlanmasını garanti etmez.

```bash
python3 campaign.py check
```

Yerel QA kapsamı LOCAL_QA.json içinde belirtilir. Gerçek Linux/GCC/112-core çözümü bu Windows ortamında yapılmaz. Profiling, yeni fizik, solver tuning veya eski sonuçlarla otomatik speedup birleştirmesi eklenmedi.
